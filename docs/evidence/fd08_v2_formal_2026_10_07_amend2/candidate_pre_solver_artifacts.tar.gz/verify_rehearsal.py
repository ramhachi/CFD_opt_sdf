import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('download',type=Path);p.add_argument('dataset',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--kernel-version',type=int,required=True);p.add_argument('--registered',action='store_true');a=p.parse_args()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def packed(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
def check(cond,msg):
    if not cond:raise ValueError(msg)
reports=list(a.download.rglob('pre_solver_execution_path.json'));check(len(reports)==1,'exactly one execution report required')
report_path=reports[0];out=report_path.parent;r=json.loads(report_path.read_text());cp=a.dataset/'criteria.json';c=json.loads(cp.read_text())
check(r['status']=='PASS_PRE_SOLVER_EXECUTION_PATH' and r['solver_started'] is False,'pre-solver terminal status')
check((out/'PASS_PRE_SOLVER_EXECUTION_PATH').read_text().strip()=='PASS_PRE_SOLVER_EXECUTION_PATH','terminal marker')
check(not list(a.download.rglob('*.forces.csv')) and not list(a.download.rglob('DONE')) and not list(a.download.rglob('result.json')) and not list(a.download.rglob('ERROR.json')),'forbidden solver/error output')
check(r['force_history_present'] is False and r['scientific_verdict'] is None,'no science verdict')
check(r['criteria_sha256']==sha(cp)==(a.dataset/'criteria.json.sha256').read_text().strip(),'criteria bytes and sidecar')
check(r['source_commit']==c['source_commit'],'exact source commit')
check(r['source_input_count']==len(c['source_inputs'])==43 and r['source_inputs_sha256']==packed(c['source_inputs']),'all source inputs')
check(r['runner_sha256']==c['source_inputs']['kernel_runner']['sha256'],'runner binding')
executed=list(a.download.rglob('pre_solver_runner.py'));check(len(executed)==1 and sha(executed[0])==r['runner_sha256'],'actual executed runner bytes')
check(r['dataset_manifest_sha256']==sha(a.dataset/'fd08_v2_dataset_manifest.json'),'manifest bytes')
inputs={x.name:sha(x) for x in sorted(a.dataset.iterdir()) if x.is_file() and x.name!='dataset-metadata.json'}
check(len(inputs)==54 and r['dataset_inventory_sha256']==packed(inputs),'exact mounted dataset bytes')
check(r['measurement']==c['measurement'] and r['runtime']==c['runtime'],'measurement/runtime configuration')
check(all(r[k]==25 for k in ['state_count','state_verification_count','verified_state_count','prepared_state_count','expected_state_count']),'all 25 states verified and prepared')
check(set(r['states'])=={x['name'] for x in c['state_inventory']},'state names')
for row in c['state_inventory']:
    s=r['states'][row['name']];conf=s['config'];env=conf['environment']
    check(s['status']=='PRE_SOLVER_PREPARED' and s['solver_started'] is False and s['state_sha256']==row['state_sha256'],'state identity/status')
    check(s['config_sha256']==packed(conf) and conf['timeout_s']==c['measurement']['per_state_timeout_s'],'actual invocation config')
    check(conf['args'][-2].endswith('/'+row['phi_raw_file']) and conf['args'][-1].endswith('/states/'+row['name']),'invocation paths')
    check(env['W4_STATE_SHA256']==row['state_sha256'] and env['W4_STATE_NPZ_SHA256']==row['npz_sha256'] and env['W4_PHI_FORTRAN_SHA256']==row['phi_fortran_order_sha256'] and env['W4_PHI_C_ORDER_SHA256']==row['phi_c_order_sha256'],'state environment hashes')
check(r['qualification_flags']==c['qualification_flags'] and not any(r['qualification_flags'].values()),'all six flags false')
check(r['last_stage']=='pre_solver_invocation','last stage')
check(len(r['gpu_inventory'])==c['runtime']['gpu_count'] and all(c['runtime']['gpu_name'] in x for x in r['gpu_inventory']),'registered GPU inventory')
check(r['runtime_smoke_sha256']==sha(out/'julia_smoke.log'),'runtime smoke bytes')
smoke=(out/'julia_smoke.log').read_text();rt=c['runtime']
markers=['W0B_SMOKE_DONE','NO_SOLVER_STEP','CUDA_FUNCTIONAL true']+[f'{label} {rt[key]}' for label,key in [('GPU_COMPUTE_CAPABILITY','compute_capability'),('CUDA_DRIVER_VERSION','cuda_driver_api_version'),('CUDA_RUNTIME_VERSION','cuda_runtime_version'),('JULIA_VERSION','julia_version'),('CUDA_JL_VERSION','cuda_jl_version'),('WATERLILY_VERSION','waterlily_version'),('GPU_NAME','gpu_name')]]
check(all(x in smoke for x in markers),'registered runtime markers')
result={'kind':'fd08_v2_actual_pre_solver_host_verification','status':'PASS','formal_registered':a.registered,'scientific_verdict':None,'formal_observation_count':0,'solver_started':False,'kernel_id':'ramhachi888/cfd-opt-sdf-fd08-v2-formal-amend2-pre-solver','kernel_version':a.kernel_version,'criteria_sha256':sha(cp),'source_commit':c['source_commit'],'runner_sha256':r['runner_sha256'],'execution_report_sha256':sha(report_path),'source_input_count':43,'state_count':25,'state_verification_count':25,'mounted_file_count':54,'gpu_inventory':r['gpu_inventory'],'driver_recorded_not_gated':r['host_driver_version_recorded_not_gated'],'started_utc':r['started_utc'],'finished_utc':r['finished_utc'],'elapsed_seconds':r['elapsed_kernel_seconds'],'runtime_markers':markers,'output_files':{x.relative_to(a.download).as_posix():sha(x) for x in sorted(a.download.rglob('*')) if x.is_file()},'qualification_flags':r['qualification_flags'],'evidence_class':'actual_registered_runner_execution_path_not_formal_science'}
data=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode();a.output.write_bytes(data);a.output.with_name(a.output.name+'.sha256').write_text(hashlib.sha256(data).hexdigest()+'\n');print(json.dumps({k:v for k,v in result.items() if k!='output_files'},indent=2))
