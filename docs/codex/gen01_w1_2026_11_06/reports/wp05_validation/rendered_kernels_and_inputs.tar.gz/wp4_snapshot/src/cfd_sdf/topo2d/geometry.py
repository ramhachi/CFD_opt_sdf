"""Source-table wing series in mm, with polygon SDFs and pre-CFD gates.

Flow is +x and z is up. Positive overlap is upstream TE-midpoint x minus
downstream LE x. Positive gap is downstream suction minimum z minus upstream
TE-midpoint z: the stable reference for a finite TE under symmetric thickening.
The source's quoted gap must not be mistaken for minimum Euclidean clearance.

The retained LE cap contains the first three source pairs. Its polygon shape
and three-point curvature proxies are preserved; no smooth analytic LE radius
is asserted. The normal-thickness floor applies from the original maximum
thickness station aft, including the TE. The intervening ramp is disclosed.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import zipfile

import numpy as np


ROOT = Path(__file__).resolve().parents[3]
C1_MM = 223.4
C_MM = 380.0
SCHEMA = "topo2d-scene-v1"
TOL = 1e-9


class GeometryError(ValueError):
    """The scene is invalid and must not be sent to a CFD solver."""


def _positive(value, name):
    if not np.isfinite(value) or value <= 0:
        raise GeometryError(f"{name} must be finite and positive")
    return float(value)


def _cross(a, b):
    return a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]


def _polygon(polygon):
    p = np.asarray(polygon, dtype=np.float64)
    if p.ndim != 2 or p.shape[1] != 2 or len(p) < 4 or not np.isfinite(p).all():
        raise GeometryError("polygon must contain finite two-dimensional vertices")
    if not np.array_equal(p[0], p[-1]):
        raise GeometryError("polygon must be explicitly closed")
    if np.any(np.linalg.norm(np.diff(p, axis=0), axis=1) <= TOL):
        raise GeometryError("polygon has a zero-length edge")
    return p


def _point_segment_squared(points, start, end):
    offset = points[:, None, :] - start[None, :, :]
    edges = end - start
    fraction = np.clip(np.einsum("psi,si->ps", offset, edges)
                       / np.einsum("si,si->s", edges, edges), 0, 1)
    delta = offset - fraction[:, :, None] * edges[None, :, :]
    return np.einsum("psi,psi->ps", delta, delta)


def polygon_sdf(points, polygon):
    """Exact distance to the closed polygon boundary, negative by winding inside.

    NumPy float64, no rasterization/interpolation. At medial axes and corners
    the derivative is undefined; away from them this has unit gradient norm.
    """
    p = _polygon(polygon)
    x = np.asarray(points, dtype=np.float64)
    if x.ndim < 1 or x.shape[-1] != 2 or not np.isfinite(x).all():
        raise GeometryError("SDF points must be finite (..., 2) coordinates")
    flat = x.reshape(-1, 2)
    a, b = p[:-1], p[1:]
    distance = np.sqrt(_point_segment_squared(flat, a, b).min(axis=1))
    cross = _cross(b[None] - a[None], flat[:, None] - a[None])
    up = (a[None, :, 1] <= flat[:, None, 1]) & (b[None, :, 1] > flat[:, None, 1])
    down = (a[None, :, 1] > flat[:, None, 1]) & (b[None, :, 1] <= flat[:, None, 1])
    winding = ((up & (cross > 0)).sum(axis=1) - (down & (cross < 0)).sum(axis=1))
    return np.where(winding != 0, -distance, distance).reshape(x.shape[:-1])


def scene_sdf(points, scene):
    """Union of wing elements; moving ground is a separate solver body."""
    if not scene.get("elements"):
        raise GeometryError("scene has no elements")
    return np.minimum.reduce([polygon_sdf(points, e["polygon_mm"]) for e in scene["elements"]])


def _intersections(a, b):
    """Inclusive intersection matrix for segment arrays (start, end)."""
    a0, a1 = a
    b0, b1 = b
    aa, ab = a0[:, None], a1[:, None]
    ba, bb = b0[None], b1[None]
    boxes = np.all(np.maximum(np.minimum(aa, ab), np.minimum(ba, bb))
                   <= np.minimum(np.maximum(aa, ab), np.maximum(ba, bb)) + TOL, axis=2)
    o1, o2 = _cross(ab - aa, ba - aa), _cross(ab - aa, bb - aa)
    o3, o4 = _cross(bb - ba, aa - ba), _cross(bb - ba, ab - ba)
    return boxes & (o1 * o2 <= TOL ** 2) & (o3 * o4 <= TOL ** 2)


def _self_intersects(p):
    hits = _intersections((p[:-1], p[1:]), (p[:-1], p[1:]))
    n = len(p) - 1
    i, j = np.indices((n, n))
    return bool(np.any(hits & (j > i + 1) & ~((i == 0) & (j == n - 1))))


def polygon_gap(a, b):
    """True minimum Euclidean boundary distance; intersection/containment is zero."""
    a, b = _polygon(a), _polygon(b)
    if np.any(_intersections((a[:-1], a[1:]), (b[:-1], b[1:]))):
        return 0.0
    if polygon_sdf(a[:1], b)[0] < 0 or polygon_sdf(b[:1], a)[0] < 0:
        return 0.0
    return float(np.sqrt(min(_point_segment_squared(a[:-1], b[:-1], b[1:]).min(),
                             _point_segment_squared(b[:-1], a[:-1], a[1:]).min())))


def _curves(suction, pressure):
    s, p = np.asarray(suction, float), np.asarray(pressure, float)
    if s.shape != p.shape or s.ndim != 2 or s.shape[1] != 2 or len(s) < 4:
        raise GeometryError("paired suction/pressure arrays must have matching (N>=4,2) shape")
    if not np.isfinite(s).all() or not np.isfinite(p).all() or not np.array_equal(s[0], p[0]):
        raise GeometryError("surface arrays must be finite and share their leading edge")
    c = (s + p) / 2
    segments = np.diff(c, axis=0)
    lengths = np.linalg.norm(segments, axis=1)
    if np.any(lengths <= TOL):
        raise GeometryError("camber line has coincident stations")
    tangent = np.gradient(c, axis=0)
    tangent /= np.linalg.norm(tangent, axis=1)[:, None]
    normal = np.column_stack((-tangent[:, 1], tangent[:, 0]))
    segment_normal = np.column_stack((-segments[:, 1], segments[:, 0])) / lengths[:, None]
    thickness = np.einsum("ij,ij->i", p - s, normal)
    if np.any(thickness[1:] <= 0):
        raise GeometryError("surface order or camber-normal thickness is invalid")
    return s, p, c, normal, segment_normal, thickness


def _controlled_minimum(suction, pressure, start):
    s, p, _, _, normal, _ = _curves(suction, pressure)
    # On each linear camber segment its normal is constant. The paired-surface
    # separation projected on it is linear, so endpoints prove the segment.
    widths0 = np.einsum("ij,ij->i", (p - s)[start:-1], normal[start:])
    widths1 = np.einsum("ij,ij->i", (p - s)[start + 1:], normal[start:])
    return float(min(widths0.min(), widths1.min()))


def thicken_element(suction, pressure, *, t_min_mm):
    """Symmetric camber-normal offsets; keep the first three pairs and TE midpoint.

    The floor is enforced continuously on paired-surface separations projected
    onto piecewise-linear camber normals, from the original maximum-thickness
    station to the TE. This is not a normal-ray diameter or a BDIM-core proof.
    The preserved cap and smoothstep ramp are explicitly excluded from that
    positive floor, since thickness at a closed leading edge is zero.
    """
    floor = _positive(t_min_mm, "t_min_mm")
    s, p, camber, normals, segment_normals, thickness = _curves(suction, pressure)
    start = int(np.argmax(thickness))
    if start < 3 or start >= len(s) - 1:
        raise GeometryError("maximum thickness must lie after the preserved LE cap and before TE")
    offsets = np.zeros(len(s))
    for j in range(start, len(s) - 1):
        for i in (j, j + 1):
            projection = float(normals[i] @ segment_normals[j])
            if projection <= 0:
                raise GeometryError("camber normal turns by >=90 degrees")
            required = (floor - (p[i] - s[i]) @ segment_normals[j]) / (2 * projection)
            offsets[i] = max(offsets[i], required)
    # The first three source pairs are unchanged. If the source maximum itself
    # is too thin (E3), reach its required offset through this disclosed ramp.
    fraction = np.arange(3, start, dtype=float) - 2
    fraction /= start - 2
    offsets[3:start] = offsets[start] * fraction ** 2 * (3 - 2 * fraction)
    lower, upper = s - offsets[:, None] * normals, p + offsets[:, None] * normals
    measured = _controlled_minimum(lower, upper, start)
    if measured < floor - TOL:
        raise GeometryError("thickness offset failed its continuous floor")
    actual = np.einsum("ij,ij->i", upper - lower, normals)
    metadata = {
        "method": "paired-camber-normal-offset-v1",
        "t_min_mm": floor,
        "controlled_from_index": start,
        "controlled_from_camber_fraction": float(np.linalg.norm(camber[start] - camber[0])
                                                  / np.linalg.norm(camber[-1] - camber[0])),
        "controlled_min_thickness_mm": measured,
        "thickness_metric": "paired-surface separation projected onto each camber segment normal",
        "bdim_core_qualified": False,
        "preserved_cap_pairs": 3,
        "cap_radius_claim": "source polygon and three-point curvature proxy only",
        "ramp": "smoothstep from paired station 2 to original maximum-thickness station",
        "global_positive_thickness_claim": False,
        "original_max_thickness_mm": float(thickness.max()),
        "max_thickness_ratio": float(np.max(actual[1:] / thickness[1:])),
        "te_midpoint_preserved": bool(np.allclose((lower[-1] + upper[-1]) / 2, camber[-1], atol=TOL, rtol=0)),
    }
    return lower, upper, metadata


def _closed_from_surfaces(s, p):
    polygon = np.vstack((s[::-1], p[1:], s[-1:]))
    return polygon


def _source_table(filename):
    path = ROOT / "data" / "zz2003" / filename
    if not path.is_file():
        raise GeometryError(f"required source table is missing: {path}")
    rows = np.loadtxt(path)
    if rows.ndim != 2 or rows.shape[1] != 4 or not np.isfinite(rows).all():
        raise GeometryError(f"invalid source table: {path}")
    return rows[:, :2] * C_MM, rows[:, 2:] * C_MM, {
        "path": path.relative_to(ROOT).as_posix(),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "url": "https://eprints.soton.ac.uk/426058/1/00192634.pdf",
        "verification": "UNVERIFIED_OCR",
        "normalization_chord_mm": C_MM,
    }


def _angle(s, p):
    chord = (s[-1] + p[-1]) / 2 - s[0]
    return math.atan2(chord[1], chord[0])


def _element(name, s, p, source_chord, nominal_chord, metadata):
    return {
        "name": name,
        "polygon_mm": _closed_from_surfaces(s, p).tolist(),
        "suction_mm": s.tolist(),
        "pressure_mm": p.tolist(),
        "leading_edge_mm": s[0].tolist(),
        "trailing_edge_midpoint_mm": ((s[-1] + p[-1]) / 2).tolist(),
        "chord_angle_rad": _angle(s, p),
        "source_chord_mm": source_chord,
        "nominal_chord_mm": nominal_chord,
        "thickening": metadata,
    }


def validate_scene(scene):
    """Recompute geometric gates; raise before CFD on any failure."""
    if scene.get("schema") != SCHEMA or not scene.get("elements"):
        raise GeometryError("unknown or empty scene schema")
    configuration = scene.get("configuration", "").removesuffix("_sharp")
    if configuration not in ("E1", "E2", "E3") or len(scene["elements"]) != int(configuration[-1]):
        raise GeometryError("unknown configuration or element count")
    dx = _positive(scene["dx_mm"], "dx_mm")
    floor = _positive(scene["t_min_mm"], "t_min_mm")
    gap_floor = _positive(scene["g_min_mm"], "g_min_mm")
    if floor < 4 * dx - TOL or gap_floor < 4 * dx - TOL:
        raise GeometryError("thickness and gap thresholds cannot be below 4 dx")
    polygons = []
    minima = []
    required = not scene["sharp_variant"]["enabled"]
    for e in scene["elements"]:
        p = _polygon(e["polygon_mm"])
        if _self_intersects(p):
            raise GeometryError(f"{e['name']}: polygon self-intersection")
        if abs(float(_cross(p[:-1], p[1:]).sum())) <= TOL:
            raise GeometryError(f"{e['name']}: degenerate polygon area")
        s, upper = np.asarray(e["suction_mm"]), np.asarray(e["pressure_mm"])
        if not np.array_equal(p, _closed_from_surfaces(s, upper)):
            raise GeometryError(f"{e['name']}: polygon/surface identity mismatch")
        if (not np.allclose(e["leading_edge_mm"], s[0], atol=TOL, rtol=0)
                or not np.allclose(e["trailing_edge_midpoint_mm"], (s[-1] + upper[-1]) / 2, atol=TOL, rtol=0)):
            raise GeometryError(f"{e['name']}: leading/trailing-edge identity mismatch")
        if required:
            start = e["thickening"]["controlled_from_index"]
            measured = _controlled_minimum(s, upper, start)
            if measured < floor - TOL:
                raise GeometryError(f"{e['name']}: controlled thickness {measured} below {floor}")
            minima.append({"element": e["name"], "thickness_mm": measured})
        polygons.append(p)
    gaps = []
    for i, a in enumerate(polygons):
        for j in range(i + 1, len(polygons)):
            gap = polygon_gap(a, polygons[j])
            if gap <= TOL:
                raise GeometryError(f"element overlap: {i}, {j}")
            if gap < gap_floor - TOL:
                raise GeometryError(f"element gap {i}, {j}: {gap:.12g} mm below {gap_floor:.12g}")
            gaps.append({"elements": [scene["elements"][i]["name"], scene["elements"][j]["name"]],
                         "distance_mm": gap})
    clearance = float(min(p[:, 1].min() for p in polygons) - scene["ground_z_mm"])
    if clearance < gap_floor - TOL:
        raise GeometryError(f"ground clearance {clearance:.12g} mm below {gap_floor:.12g}")
    return {"accepted": True, "thickness_required": required,
            "thickness_scope": "original maximum-thickness station aft; LE cap and ramp excluded",
            "thickness_metric": "paired-surface separation projected onto each camber segment normal",
            "bdim_core_qualified": False,
            "controlled_minima": minima, "pair_gaps_mm": gaps,
            "clearance_mm": clearance, "self_intersections": False, "overlap": False}


def build_scene(configuration, *, height_mm, dx_mm, t_min_cells=4, g_min_cells=4,
                overlap_mm=9, gap_mm=12):
    """Build E1/E2/E3, then refuse invalid thickness/gaps/clearance before CFD.

    Gap and overlap are signed placement quantities defined in this module's
    docstring. The separate g_min gate uses true minimum Euclidean distance.
    E3 uses two half-scale source flaps with equal angle increments. `_sharp`
    is the registration's legacy arm name for unthickened finite-TE originals.
    """
    sharp = configuration.endswith("_sharp") if isinstance(configuration, str) else False
    base = configuration.removesuffix("_sharp") if isinstance(configuration, str) else ""
    if base not in ("E1", "E2", "E3"):
        raise GeometryError(f"unknown configuration: {configuration}")
    height = _positive(height_mm, "height_mm")
    dx = _positive(dx_mm, "dx_mm")
    t_cells, g_cells = _positive(t_min_cells, "t_min_cells"), _positive(g_min_cells, "g_min_cells")
    if min(t_cells, g_cells) < 4:
        raise GeometryError("thickness and gap thresholds cannot be below 4 dx")
    if not np.isfinite(overlap_mm) or not np.isfinite(gap_mm):
        raise GeometryError("overlap and gap must be finite")
    ms, mp, main_source = _source_table("main_element_table3.dat")
    fs, fp, flap_source = _source_table("flap_table4.dat")
    main_angle, flap_angle = _angle(ms, mp), _angle(fs, fp)
    flap_origin = fs[0].copy()
    original_chords = [float(np.linalg.norm((s[-1] + p[-1]) / 2 - s[0]))
                       for s, p in ((ms, mp), (fs, fp))]
    profiles = [("main", ms, mp, original_chords[0], C1_MM)]
    if base == "E2":
        profiles.append(("flap1", fs, fp, original_chords[1], 165.7))
    elif base == "E3":
        for i in (1, 2):
            angle = main_angle + i * (flap_angle - main_angle) / 2
            turn = angle - flap_angle
            rotation = np.array([[math.cos(turn), -math.sin(turn)],
                                 [math.sin(turn), math.cos(turn)]])
            profiles.append((f"flap{i}", (fs - flap_origin) @ rotation.T / 2,
                             (fp - flap_origin) @ rotation.T / 2, original_chords[1] / 2, 82.85))
    elements, transformations = [], []
    for name, suction, pressure, source_chord, nominal in profiles:
        if sharp:
            metadata = {"method": "unthickened-source", "max_thickness_ratio": 1.0,
                        "global_positive_thickness_claim": False}
        else:
            suction, pressure, metadata = thicken_element(suction, pressure, t_min_mm=t_cells * dx)
        if not elements:
            shift = np.array([0.0, height - min(suction[:, 1].min(), pressure[:, 1].min())])
        else:
            previous_te = np.asarray(elements[-1]["trailing_edge_midpoint_mm"])
            shift = np.array([previous_te[0] - overlap_mm - suction[0, 0],
                              previous_te[1] + gap_mm - suction[:, 1].min()])
        suction, pressure = suction + shift, pressure + shift
        elements.append(_element(name, suction, pressure, source_chord, nominal, metadata))
        transformations.append({"element": name, "translation_mm": shift.tolist(),
                                "source_scale": 0.5 if base == "E3" and name != "main" else 1.0})
    scene = {
        "schema": SCHEMA, "configuration": configuration, "height_mm": height, "dx_mm": dx,
        "ground_z_mm": 0.0, "t_min_mm": t_cells * dx, "g_min_mm": g_cells * dx,
        "normalizations": {"c1_mm": C1_MM, "c_mm": C_MM,
                           "h_over_c1": height / C1_MM, "h_over_c": height / C_MM},
        "placement": {"overlap_mm": float(overlap_mm), "gap_mm": float(gap_mm),
                      "gap_reference": "upstream trailing-edge midpoint",
                      "flap_rotation_center_mm": [0.567 * C_MM, 0.076 * C_MM],
                      "e3_rule": "two half-scale source profiles; equal main-to-flap angle increments",
                      "transformations": transformations},
        "sharp_variant": {"enabled": sharp, "mathematically_sharp": False,
                          "meaning": "legacy registration arm name; original finite trailing edges retained"},
        "elements": elements,
        "thickening": [{"element": e["name"], **e["thickening"]} for e in elements],
        "sources": [main_source, flap_source],
    }
    scene["gates"] = validate_scene(scene)
    return scene


def write_scene(scene, path):
    """Export deterministic JSON after rechecking gates."""
    validate_scene(scene)
    Path(path).write_text(json.dumps(scene, sort_keys=True, indent=2, allow_nan=False) + "\n")


def save_npz(scene, path):
    """Export deterministic, pickle-free NPZ polygons and the complete JSON record."""
    validate_scene(scene)
    arrays = {f"polygon_{i}_mm": np.asarray(e["polygon_mm"], dtype="<f8")
              for i, e in enumerate(scene["elements"])}
    arrays["scene_json"] = np.array(json.dumps(scene, sort_keys=True, allow_nan=False))
    # np.savez embeds current ZIP timestamps on some NumPy versions. Fix only
    # that container metadata; .npy payloads use the standard NumPy writer.
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, array in arrays.items():
            buffer = io.BytesIO()
            np.save(buffer, array, allow_pickle=False)
            item = zipfile.ZipInfo(f"{name}.npy", date_time=(1980, 1, 1, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(item, buffer.getvalue())


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--configuration", required=True, choices=[f"E{i}{suffix}" for i in (1, 2, 3) for suffix in ("", "_sharp")])
    parser.add_argument("--height-mm", type=float, required=True)
    parser.add_argument("--dx-mm", type=float, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--npz-output", type=Path)
    args = parser.parse_args(argv)
    scene = build_scene(args.configuration, height_mm=args.height_mm, dx_mm=args.dx_mm)
    write_scene(scene, args.output)
    if args.npz_output:
        save_npz(scene, args.npz_output)
    print(json.dumps({"output": str(args.output), "gates": scene["gates"]}, sort_keys=True))


if __name__ == "__main__":
    main()
